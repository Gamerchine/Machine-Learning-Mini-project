import pandas as pd
import numpy as np
from matplotlib import pyplot as plt

df1=pd.read_csv('football.csv')

columns=['club_logo','special','ID','birth_date','real_face','flag','photo',
    '1_on_1_rush_trait',
 'acrobatic_clearance_trait',
 'argues_with_officials_trait',
 'avoids_using_weaker_foot_trait',
 'backs_into_player_trait',
 'bicycle_kicks_trait',
 'cautious_with_crosses_trait',
 'chip_shot_trait',
 'chipped_penalty_trait',
 'comes_for_crosses_trait',
 'corner_specialist_trait',
 'diver_trait',
 'dives_into_tackles_trait',
 'diving_header_trait',
 'driven_pass_trait',
 'early_crosser_trait',
 "fan's_favourite_trait",
 'fancy_flicks_trait',
 'finesse_shot_trait',
 'flair_trait',
 'flair_passes_trait',
 'gk_flat_kick_trait',
 'gk_long_throw_trait',
 'gk_up_for_corners_trait',
 'giant_throw_in_trait',
 'inflexible_trait',
 'injury_free_trait',
 'injury_prone_trait',
 'leadership_trait',
 'long_passer_trait',
 'long_shot_taker_trait',
 'long_throw_in_trait',
 'one_club_player_trait',
 'outside_foot_shot_trait',
 'playmaker_trait',
 'power_free_kick_trait',
 'power_header_trait',
 'puncher_trait',
 'rushes_out_of_goal_trait',
 'saves_with_feet_trait',
 'second_wind_trait',
 'selfish_trait',
 'skilled_dribbling_trait',
 'stutter_penalty_trait',
 'swerve_pass_trait',
 'takes_finesse_free_kicks_trait',
 'target_forward_trait',
 'team_player_trait',
 'technical_dribbler_trait',
 'tries_to_beat_defensive_line_trait',
 'poacher_speciality',
 'speedster_speciality',
 'aerial_threat_speciality',
 'dribbler_speciality',
 'playmaker_speciality',
 'engine_speciality',
 'distance_shooter_speciality',
 'crosser_speciality',
 'free_kick_specialist_speciality',
 'tackling_speciality',
 'tactician_speciality',
 'acrobat_speciality',
 'strength_speciality',
 'clinical_finisher_speciality',
]

df1.drop(columns,inplace=True,axis=1)
df1.to_csv('refined_football.csv')

df2=pd.read_csv('refined_football.csv')

df3=df2[df2.prefers_rw==True]
df4=df2[df2.prefers_cf==True]
df5=df2[df2.prefers_st==True]
df6=df2[df2.prefers_lw==True]

dfFor=pd.concat([df6,df5,df4,df3])
dfFor=dfFor.drop_duplicates()
dfFor=dfFor.reset_index(drop=True)
dfFor.to_csv('Forward.csv')

df7=df2[df2.prefers_rm==True]
df8=df2[df2.prefers_lm==True]
df9=df2[df2.prefers_cam==True]
df10=df2[df2.prefers_cm==True]
df11=df2[df2.prefers_cdm==True]

dfMid=pd.concat([df7,df8,df9,df10,df11])
dfMid=dfMid.drop_duplicates()
dfMid=dfMid.reset_index(drop=True)
dfMid.to_csv('Midfielders.csv')

df12=df2[df2.prefers_rb==True]
df13=df2[df2.prefers_rwb==True]
df14=df2[df2.prefers_cb==True]
df15=df2[df2.prefers_lb==True]
df16=df2[df2.prefers_lwb==True]

dfDef=pd.concat([df12,df13,df14,df15,df16])
dfDef=dfDef.drop_duplicates()
dfDef=dfDef.reset_index(drop=True)
dfDef.to_csv('Defenders.csv')

df17=df2[df2.prefers_gk==True]
df17.to_csv('Goalkeepers.csv')

df18=df2[df2.eur_value>20000000]
df19=df2[df2.eur_value<=20000000]
df20=df19[df19.eur_value>10000000].sample(n=30)
dfTransfer=pd.concat([df18,df20])
dfTransfer.to_csv('Transfer1.csv')

df21=df2[df2.overall<80]
df21=df21[df21.overall>70]
df21.to_csv("Transfer2.csv")

df22=df2[df2.overall<70]
df22=df22[df22.overall<70]
df22.to_csv("Transfer3.csv")

df23=df2[df2.overall<60]
df23=df23[df23.overall>50]
df23.to_csv("Transfer4.csv")

df24=df2[df2.overall<50]
df24.to_csv("Transfer5.csv")
