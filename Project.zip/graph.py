import pandas as pd
import numpy as np
from statistics import mean
from matplotlib import pyplot as plt
from sklearn import model_selection
from sklearn.linear_model import LinearRegression

#Analysis of Transfer fees of different types of players using pie chart

df1=pd.read_csv('Data/Forward.csv')
df2=pd.read_csv('Data/Midfielders.csv')
df3=pd.read_csv('Data/Defenders.csv')
df4=pd.read_csv('Data/Goalkeepers.csv')

a=df1['eur_value'].mean()
b=df2['eur_value'].mean()
c=df3['eur_value'].mean()
d=df4['eur_value'].mean()

sizes=[a,b,c,d]
labels='Forwards','MidFielders','Defenders','Goalkeepers'
colors = ['gold', 'yellowgreen', 'lightcoral', 'lightskyblue']
explode = (0.1, 0, 0, 0)

plt.title("Players Market Value Distribution",fontsize = 25,color = "Red")
plt.pie(sizes, explode=explode, labels=labels, colors=colors,
        autopct='%1.1f%%', shadow=True, startangle=140)
plt.axis('equal')
plt.show()
