from statistics import mean
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import sys

df=pd.read_csv('Data/Transfer1.csv')

xs = np.array(df['eur_value'])
ys = np.array(df['eur_wage'])

def best_fit_slope_and_intercept(xs,ys):
    m = (( (mean(xs)*mean(ys)) - mean(xs*ys) )/((mean(xs)**2)-(mean(xs**2))))
    b = mean(ys)-m*mean(xs)
    return m,b

def squared_error(ys_orig, ys_line):
    return sum((ys_line-ys_orig)**2)

def coefficient_of_determination(ys_orig,ys_line):
    ys_mean_line = [mean(ys_orig) for y in ys_orig]
    squared_error_regr = squared_error(ys_orig, ys_line)
    squared_error_y_mean = squared_error(ys_orig, ys_mean_line)
    return 1-(squared_error_regr/squared_error_y_mean)

m,b=best_fit_slope_and_intercept(xs,ys)

regression_line = [(m*x)+b for x in xs]
r_squared=coefficient_of_determination(ys,regression_line)

predict_x=float(sys.argv[1])*1000000
predict_y=(m*predict_x)+b
predict_y=round(predict_y/1000,2)

Sc = round(float(r_squared*100),2)

print("The Predicted Wage of the player is",predict_y,"Euros per week with an accuracy of",Sc,"%")
