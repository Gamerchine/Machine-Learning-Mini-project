import sys
import pandas as pd
import numpy as np
from statistics import mean
from matplotlib import pyplot as plt
from sklearn import model_selection
from sklearn.linear_model import LinearRegression

dfp=pd.read_csv('Data/refined_football.csv')

X1 = np.array(dfp[['age','overall']])
y1 = np.array(dfp['potential'])

X1_train, X1_test, y1_train, y1_test = model_selection.train_test_split(X1,y1,test_size=0.1)

bfl=LinearRegression()
bfl.fit(X1_train,y1_train)
Sc = bfl.score(X1_test,y1_test)

age=float(sys.argv[1])
overall=float(sys.argv[2])

#age=float(input("Enter the current age of your Player: "))
#overall=float(input("Enter the rating of your player from 75 to 100: "))

x = bfl.predict([[age,overall]])
val = int((x[0]))

if val>100:
    val=100

Sc = round(float(Sc*100),2)

print("The Predicted Potential of the player is:",val,"/100 with an accuracy of:",Sc,"%")
