import sys
import pandas as pd
import numpy as np
from statistics import mean
from matplotlib import pyplot as plt
from sklearn import model_selection
from sklearn.linear_model import LinearRegression

age=float(sys.argv[1])
overall=float(sys.argv[2])

if overall>80:
    df=pd.read_csv('Data/Transfer1.csv')
elif overall>70:
    df=pd.read_csv('Data/Transfer2.csv')
elif overall>60:
    df=pd.read_csv('Data/Transfer3.csv')
elif overall>50:
    df=pd.read_csv('Data/Transfer4.csv')
elif overall>40:
    df=pd.read_csv('Data/Transfer5.csv')

X=np.array(df[['age','overall']])
y=np.array(df['eur_value'])

X_train, X_test, y_train, y_test = model_selection.train_test_split(X,y,test_size=0.1)

bfl=LinearRegression()
bfl.fit(X_train,y_train)
Sc = bfl.score(X_test,y_test)

#age=float(input("Enter the current age of your Player: "))
#overall=float(input("Enter the rating of your player from 75 to 100: "))

x = ((bfl.predict([[age,overall]])))
val = int((x[0]))
val = float(val)/1000000

flag=0
if val<1:
    val=val*1000
    flag=1

val = round(val,2)
Sc = round(float(Sc*100),2)

if flag==1:
    print("The Predicted Transfer Value of the player is:",val,"Thousand Euros with an accuracy of:",Sc,"%")
elif flag==0:
    print("The Predicted Transfer Value of the player is:",val,"Million Euros with an accuracy of:",Sc,"%")
